package com.example.projetobd;

import android.os.Parcel;
import android.os.Parcelable;

public class Musica implements Parcelable {

    private int id;
    private String nome;
    private int ano;
    private String compositor;

    public Musica(int id, String nome, int ano, String compositor){
        this.id = id;
        this.nome = nome;
        this.ano = ano;
        this.compositor = compositor;
    }

    public Musica( String nome, int ano, String compositor){
        this.nome = nome;
        this.ano = ano;
        this.compositor = compositor;
    }

    public Musica() {

    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }

    public void setNome(String nome) { this.nome = nome; }

    public int getAno() { return ano; }

    public void setAno(int ano) { this.ano = ano; }

    public String getCompositor() { return compositor; }

    public void setCompositor(String compositor) { this.compositor = compositor; }

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(nome);
        dest.writeInt(ano);
        dest.writeString(compositor);
    }

    public void readFromParcel(Parcel parcel){
        this.id = parcel.readInt();
        this.nome = parcel.readString();
        this.ano = parcel.readInt();
        this.compositor = parcel.readString();
    }

    public static final Parcelable.Creator<Musica> CREATOR = new Parcelable.Creator<Musica>() {
        @Override
        public Musica createFromParcel(Parcel p) {
            Musica m = new Musica();
            m.readFromParcel(p);
            return m;
        }

        @Override
        public Musica[] newArray(int size) {
            return new Musica[size];
        }
    };
}