package com.example.projetobd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;

public class InsertMusicaActivity extends AppCompatActivity {

    private EditText nomeEditText;
    private EditText anoEditText;
    private EditText compositorEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_musica);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nomeEditText = (EditText) findViewById(R.id.nomeEditText);
        anoEditText = (EditText) findViewById(R.id.anoEditText);
        compositorEditText = (EditText) findViewById(R.id.compositorEditText);
    }

    public void Insert(View view){
        Musica musica = new Musica();
        musica.setNome(nomeEditText.getText().toString());
        musica.setAno(Integer.valueOf(anoEditText.getText().toString()));
        musica.setCompositor(compositorEditText.getText().toString());

        Intent returnIntent = new Intent();
        Bundle returnBundle = new Bundle();
        returnBundle.putParcelable("musica", musica);
        returnIntent.putExtras(returnBundle);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}
