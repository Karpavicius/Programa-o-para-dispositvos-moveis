package com.example.projetobd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "ExercicioBD.db";
    public static final String MUSICAS_TABLE_NAME = "musica";
    public static final String MUSICAS_COLUMN_ID = "id";
    public static final String MUSICAS_COLUMN_NOME = "nome";
    public static final String MUSICAS_COLUMN_ANO = "ano";
    public static final String MUSICAS_COLUMN_COMPOSITOR = "compositor";

    public DBHelper(Context context){
        super(context, DATABASE_NAME , null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + MUSICAS_TABLE_NAME
                + "("+MUSICAS_COLUMN_ID + " integer primary key, "
                + MUSICAS_COLUMN_NOME + " text, "
                + MUSICAS_COLUMN_ANO + " integer, "
                + MUSICAS_COLUMN_COMPOSITOR + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS "+MUSICAS_TABLE_NAME);
        onCreate(db);
    }

    public long insertFilme(Musica musica){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MUSICAS_COLUMN_NOME, musica.getNome());
        contentValues.put(MUSICAS_COLUMN_ANO, musica.getAno());
        contentValues.put(MUSICAS_COLUMN_COMPOSITOR, musica.getCompositor());
        long i = db.insert(MUSICAS_TABLE_NAME, null, contentValues);
        db.close();
        return i;
    }

    public Musica getMusica(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+ MUSICAS_TABLE_NAME +" where "
                + MUSICAS_COLUMN_ID +"="+id+"", null );
        res.moveToFirst();
        Musica musica = new Musica(res.getInt(res.getColumnIndex(MUSICAS_COLUMN_ID)),
                res.getString(res.getColumnIndex(MUSICAS_COLUMN_NOME)),
                res.getInt(res.getColumnIndex(MUSICAS_COLUMN_ANO)),
                res.getString(res.getColumnIndex(MUSICAS_COLUMN_COMPOSITOR)));
        db.close();
        return musica;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, MUSICAS_TABLE_NAME);
        db.close();
        return numRows;
    }

    public int updateMusica(Musica musica){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MUSICAS_COLUMN_NOME, musica.getNome());
        contentValues.put(MUSICAS_COLUMN_ANO, musica.getAno());
        contentValues.put(MUSICAS_COLUMN_COMPOSITOR, musica.getCompositor());
        db.close();
        return db.update(MUSICAS_TABLE_NAME, contentValues, MUSICAS_COLUMN_ID+" = ?", new String[] {Integer.toString(musica.getId())} );
    }

    public Integer deleteMusica (int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int i =  db.delete(MUSICAS_TABLE_NAME,
                MUSICAS_COLUMN_ID+" = ?",
                new String[] { Integer.toString(id) });
        db.close();
        return i;
    }

    public ArrayList<Musica> getAllMusic(){
        ArrayList<Musica> musica = new ArrayList<Musica>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+MUSICAS_TABLE_NAME, null );
        res.moveToFirst();
        while(res.isAfterLast() == false){
            musica.add(new Musica(res.getInt(res.getColumnIndex(MUSICAS_COLUMN_ID)),
                    res.getString(res.getColumnIndex(MUSICAS_COLUMN_NOME)),
                    res.getInt(res.getColumnIndex(MUSICAS_COLUMN_ANO)),
                    res.getString(res.getColumnIndex(MUSICAS_COLUMN_COMPOSITOR))));
            res.moveToNext();
        }
        db.close();
        return musica;
    }
}
