package com.example.projetobd;

import android.os.Parcel;
import android.os.Parcelable;

public class Compositor implements Parcelable {

    private int id;
    private String nome;

    public void Compositor(int id, String nome){
        this.id = id;
        this.nome = nome;
    }

    public void Compositor(String nome){
        this.nome = nome;
    }

    public Compositor(){ }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    protected Compositor(Parcel in) { }

    public static final Parcelable.Creator<Compositor> CREATOR = new Parcelable.Creator<Compositor>() {
        @Override
        public Compositor createFromParcel(Parcel p) {
            Compositor c = new Compositor();
            c.readFromParcel(p);
            return new Compositor(p);
        }

        @Override
        public Compositor[] newArray(int size) { return new Compositor[size]; }
    };

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(nome);
    }

    public void readFromParcel(Parcel parcel){
        this.id = parcel.readInt();
        this.nome = parcel.readString();
    }
}
