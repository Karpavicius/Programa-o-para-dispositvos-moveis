package com.example.projetobd;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class MusicaAdapter  extends RecyclerView.Adapter {

    private List<Musica> listaMusicas;

    public MusicaAdapter(){ listaMusicas = new ArrayList<Musica>();}

    public List<Musica> getListaMusicas(){ return listaMusicas;}

    public void setListaMusicas(List<Musica> novaListaMusicas){
        while(getItemCount()>0)
            remover(0);

        for (Musica musica: novaListaMusicas)
            inserir(musica);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i){
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.musica_row, viewGroup, false);
        MusicaViewHolder holder = new MusicaViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i){
        MusicaViewHolder holder = (MusicaViewHolder) viewHolder;
        holder.nomeTextView.setText(listaMusicas.get(i).getNome());
        holder.anoTextView.setText(String.valueOf(listaMusicas.get(i).getAno()));
         holder.compositorTextView.setText(listaMusicas.get(i).getCompositor());
     }

    @Override
    public int getItemCount(){ return listaMusicas.size(); }

    public void inserir(Musica musica){
        listaMusicas.add(musica);
        notifyItemInserted(getItemCount());
    }

    public void update(Musica musica, int position){
        listaMusicas.get(position).setNome(musica.getNome());
        listaMusicas.get(position).setAno(musica.getAno());
        listaMusicas.get(position).setCompositor(musica.getCompositor());
        notifyItemChanged(position);
    }

    public void remover(int position){
        listaMusicas.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,this.getItemCount());
    }

    public static class MusicaViewHolder extends RecyclerView.ViewHolder {

        TextView nomeTextView;
        TextView anoTextView;
        TextView compositorTextView;

        public MusicaViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setTag(this);
            nomeTextView = (TextView) itemView.findViewById(R.id.nomeTextView);
            anoTextView = (TextView) itemView.findViewById(R.id.anoTextView);
            compositorTextView = (TextView) itemView.findViewById(R.id.compositorTextView);
        }
    }
}
