package com.example.aplicativoderolagemdedadode6facescomlogin;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void hidePassword(View v){
        final CheckBox showPassword = (CheckBox) findViewById(R.id.checkBox);
        final EditText password = (EditText) findViewById(R.id.senha);

        if(showPassword.isChecked()){
            password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        }else{
            password.setTransformationMethod(PasswordTransformationMethod.getInstance());
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        final Button butaum = (Button)findViewById(R.id.button2);

        butaum.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                EditText nome=(EditText) findViewById(R.id.usuario);
                EditText senha=(EditText) findViewById(R.id.senha);

                if(nome.getText().toString().equals("Evelin") && senha.getText().toString().equals("2003")){
                    Intent intent = new Intent(nome.getContext(), RolagemDeDados.class);
                    intent.putExtra("nomeUsuario", nome.getText().toString());
                    startActivityForResult(intent,1);
                }else {
                    Toast toast = null;
                    if (!nome.getText().toString().equals("Evelin")) {
                        toast = Toast.makeText(getApplicationContext(), "Usuário incorreto.", Toast.LENGTH_SHORT);
                    }
                    if (!senha.getText().toString().equals("2003")) {
                        toast = Toast.makeText(getApplicationContext(), "Senha incorreta.", Toast.LENGTH_SHORT);
                    }
                    toast.show();
                }
            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();


        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
