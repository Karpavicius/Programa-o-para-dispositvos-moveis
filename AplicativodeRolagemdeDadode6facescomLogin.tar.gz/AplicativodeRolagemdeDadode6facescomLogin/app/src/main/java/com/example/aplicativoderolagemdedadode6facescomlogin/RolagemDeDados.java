package com.example.aplicativoderolagemdedadode6facescomlogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class RolagemDeDados extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setContentView(R.layout.activity_rolagem_de_dados);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Scroll");

        final String var = getIntent().getStringExtra("nomeUsuario");
        final TextView textView = (TextView)findViewById(R.id.bemVindo);

        textView.setText("Welcome"+var+"!");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rolagem_de_dados);
    }

    public void scroll(View v){

        final Random number = new Random();
        final ImageView image = (ImageView)findViewById(R.id.imageView);

        switch (number.nextInt(6)){

            case 0:
                image.setImageResource(R.drawable.um);
                break;
            case 1:
                image.setImageResource(R.drawable.dois);
                break;
            case 2:
                image.setImageResource(R.drawable.tres);
                break;
            case 3:
                image.setImageResource(R.drawable.quatro);
                break;
            case 4:
                image.setImageResource(R.drawable.cinco);
                break;
            case 5:
                image.setImageResource(R.drawable.seis);
                break;
        }
    }
}
